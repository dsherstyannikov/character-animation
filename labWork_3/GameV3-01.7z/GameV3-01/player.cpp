#include <gl/gl.h>
#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <malloc.h>
#include "player.h"

void Player_Move(){


    if (GetKeyState(VK_SPACE) < 0 && player.isOnFloor == true){
        player.jumpHeight = player.gravity*2;
        player.isOnFloor=false;
        player.frameLine = JUMP;
    }

    if (GetKeyState('D') < 0 ){
            player.lookRight = true;
        player.posX += player.velocity;
        if(player.isOnFloor){
            player.frameLine = WALK;
        }
    } else if (GetKeyState('A') < 0) {
        player.lookRight = false;
        player.posX -= player.velocity;
        if(player.isOnFloor){
            player.frameLine = WALK;
        }
    } else if (player.isOnFloor){
        player.frameLine = STAY;
    }

    if(player.jumpHeight == -1){
        player.isOnFloor = true;
    } else if(player.isOnFloor == false){
        player.posY -= player.jumpHeight - player.gravity;
        player.jumpHeight -= 1;
    }
}
