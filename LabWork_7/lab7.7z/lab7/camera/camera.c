#include <GL/gl.h>
#include <windows.h>
#include <math.h>
#include "camera.h"

struct Camera camera = {0,0,1.7,0,0};

void Camera_Apply(){
    glRotatef(-camera.xrot, 1, 0, 0);
    glRotatef(-camera.zrot, 0, 0, 1);
    glTranslatef(-camera.x, -camera.y, -camera.z);
}

void Camera_Rotation(float xAngle, float zAngle){
    camera.zrot += zAngle;
    if(camera.zrot < 0) camera.zrot += 360;
    if(camera.zrot > 360) camera.zrot -= 360;
    camera.xrot += xAngle;
    if(camera.xrot <= 0) camera.xrot = 0;
    if(camera.xrot >= 180) camera.xrot = 180;
}

void Camera_AutoMoveByMouse(int centerX, int centerY, float speed){
    POINT cur;
    POINT base = {centerX, centerY};
    GetCursorPos(&cur);
    Camera_Rotation((base.y - cur.y) * speed, (base.x - cur.x) * speed );
    SetCursorPos(base.x, base.y);
}

void Camera_MoveDirectional(int forwardMove, int rightMove, float speed){

    float ugol= -camera.zrot/180*M_PI;

    if (forwardMove>0)
            ugol+=rightMove>0 ? M_PI_4 :(rightMove<0 ? -M_PI_4 :0);
    if (forwardMove<0)
            ugol+=M_PI + (rightMove>0 ? -M_PI_4 :(rightMove<0 ? M_PI_4 :0));
    if (forwardMove==0) {
        ugol +=rightMove > 0? M_PI_2 : -M_PI_2;
        if (rightMove==0) speed=0;
    }
    if (speed!=0){
        camera.x+= sin(ugol)*speed;
        camera.y+= cos(ugol)*speed;
    }
}
