#include <windows.h>
#include <gl/gl.h>
#include <math.h>
//#include <stdlib.h>
#include "camera/camera.h"

LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM);
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);
void DisableOpenGL(HWND, HDC, HGLRC);

float PI = 3.14159265358979323846;

float sides = 11; //���������� ������
float height = 1; //���. ������
float height2 = 0.1; //���. ������ ��� ������������
float rad = 1; //������� � ������ ������
float midRad = 0.8; //������� ������
float count = 8; //���������� ��������

float vertex[] = {-0.2,-0.2,0,  0.2,-0.2,0,  0.2,0.2,0,  -0.2,0.2,0};

void draw_triangles(double r, double n, float transperency) {

    double a1 = (360.0 / n) * 0.5;
    double a2 = 90.0 - a1;

    double c = r / sin(a2);
    double side = 2 * r * tan(PI/n) / 2;


    GLfloat vertices[] = {
        0.0f, 0.0f, 0.0f,
        r, side, 0.0f,
        r, -side, 0.0f
    };


    GLfloat normals[] = {
        0.0f, 0.0f, 1.0f,
        0.0f, 0.0f, 1.0f,
        0.0f, 0.0f, 1.0f
    };

    GLuint indices[] = {
        0, 1, 2
    };

    glColor4f(1-transperency, 0.5, 0.5, transperency);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);

    glVertexPointer(3, GL_FLOAT, 0, vertices);
    glNormalPointer(GL_FLOAT, 0, normals);

    glPushMatrix();


    for (int i = 0; i < n; i++) {
        glPushMatrix();
        glRotatef(i * 360.0 / n , 0.0f, 0.0f, 1.0f);
        glTranslatef(0.0f, 0.0f, 0.0f);
        glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, indices);
        glPopMatrix();
    }
    glPopMatrix();


    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
}

void draw_squares(double r, double midr, int n, double height, float transperency) {
    double a1 = (360.0 / n) * 0.5;
    double a2 = 90.0 - a1;

    double c = r / sin(a2);
    double side = 2 * r * tan(PI/n) / 2;
    double midside = 2 * midr * tan(PI/n) / 2;

    GLfloat vertices[] = {
        midr - r, -midside,  height / 2,
        midr - r,  midside,  height / 2,
        0.0f,  side, 0,
        0.0f, -side, 0
    };


    GLfloat normals[] = {
        1, 0,  0,
        1, 0,  0,
        1, 0,  0,
        1, 0,  0
    };
    GLuint indices[] = {
        0, 1, 2,
        0, 2, 3
    };

    glColor4f(0.5, 1-transperency, 0.5, transperency);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);

    glVertexPointer(3, GL_FLOAT, 0, vertices);
    glNormalPointer(GL_FLOAT, 0, normals);

    glPushMatrix();
    float tr = 1.0f;
    for (int i = 0; i < n; i++) {
        glPushMatrix();
        glRotatef(i * 360.0 / n, 0.0f, 0.0f, 1.0f);
        glTranslatef(r, -0.0f, -0.0f);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, indices);
        glPopMatrix();
    }
    glPopMatrix();

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
}

void WndResize(int x, int y){
    glViewport(0,0,x,y);
    float k = x / (float)y;
    float sz = 0.1;
    glLoadIdentity();
    glFrustum(-k*sz, k*sz, -sz, sz, sz*2, 100);//persp. proectia
}

void Camera_Move(){
    Camera_MoveDirectional(GetKeyState('W')< 0 ? 1 : GetKeyState('S')< 0 ? -1 : 0,GetKeyState('D')< 0 ? 1 : GetKeyState('A')< 0 ? -1 : 0,0.3);
    Camera_AutoMoveByMouse(400,400,0.2);
}

void Rec(){
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0 ,vertex);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    glDisableClientState(GL_VERTEX_ARRAY);
}

void draw_chess(int size)
{

    float normal_vert[]={0,0,1, 0,0,1, 0,0,1, 0,0,1};
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT,0,&normal_vert);


    float color = 0.0;
    int start = floor(size / 2);
    for(float i = 0; i < size; i++){
        color =  fmod((color + 1.0), 2.0);
        for(float j = 0; j < size; j++){
            color =  fmod((color + 1.0), 2.0);
            glBegin(GL_QUADS);
            glColor3f(color,color,color);

            glVertex3f(0.0f+i-start, 0.0f+j-start, 0.0f);

            glVertex3f(0.0f+i-start, 1.0f+j-start, 0.0f);

            glVertex3f(1.0f+i-start, 1.0f+j-start, 0.0f);

            glVertex3f(1.0f+i-start, 0.0f+j-start, 0.0f);


            glEnd();
        }
    }
    glDisable(GL_NORMAL_ARRAY);
}
void Init_Light()
{
    glEnable(GL_LIGHTING); //����� ��������� ��� ����� ������������
    glShadeModel(GL_SMOOTH);
    GLfloat light_position[] = { 0, 0, 0.0, 1.0f }; //������� ���������
    GLfloat light_spot_direction[] = {10.0, 0.0, 0.0, 1.0}; // ������� ����
    GLfloat light_ambient[] = { 0.5f, 0.5f, 0.5f, 1.0f }; //���������
    GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f }; //���������
    GLfloat light_specular[] = { 0.6f, 0.6f, 0.6f, 1.0f }; //���������
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 75); // ����� ��� ������������� ���������
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light_spot_direction);
    glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 8.0); // ���������� �������� ������������� �������������� �������� ��� ��������� LIGHT0
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glEnable(GL_LIGHT0); // �������� ����� LIGHT0


}
void Init_Material()
{
    glEnable(GL_COLOR_MATERIAL); //���������� ������������� ���������
    glShadeModel(GL_SMOOTH); // ���������� �������



    GLfloat material_ambient[] = {1.0f, 1.0f, 1.0f, 1.0f};

    GLfloat material_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };

    GLfloat material_specular[] = { 1.0f, 1.0f, 1.0f, 32.0f };
    GLfloat material_shininess[] = { 1.0f }; //����� ���������
    glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess);


    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    //glBlendFunc(GL_ONE, GL_ONE);
}



int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{
    WNDCLASSEX wcex;
    HWND hwnd;
    HDC hDC;
    HGLRC hRC;
    MSG msg;
    BOOL bQuit = FALSE;
    float theta = 0.0f;

    /* register window class */
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC;
    wcex.lpfnWndProc = WindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = "GLSample";
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);;


    if (!RegisterClassEx(&wcex))
        return 0;

    /* create main window */
    hwnd = CreateWindowEx(0,
                          "GLSample",
                          "OpenGL Sample",
                          WS_OVERLAPPEDWINDOW,
                          CW_USEDEFAULT,
                          CW_USEDEFAULT,
                          1280,
                          960,
                          NULL,
                          NULL,
                          hInstance,
                          NULL);

    ShowWindow(hwnd, nCmdShow);

    /* enable OpenGL for the window */
    EnableOpenGL(hwnd, &hDC, &hRC);

    RECT rct;
    GetClientRect(hwnd, &rct);
    WndResize(rct.right, rct.bottom);
    glEnable(GL_DEPTH_TEST);

    /* program main loop */
    while (!bQuit)
    {
        /* check for messages */
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            /* handle or dispatch messages */
            if (msg.message == WM_QUIT)
            {
                bQuit = TRUE;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        else
        {
            /* OpenGL animation code goes here */

            glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //������� ������ �������




            glPushMatrix();

            if(GetForegroundWindow() == hwnd){
                Camera_Move();
            }
            Camera_Apply();



            glPushMatrix();
                /*glTranslatef(0.0f, 0.0f, 0.8f);
                glColor3f(1,1,1);
                glPushMatrix();
                    glRotatef(theta, 0, 0, 1);
                    Init_Light();
                    Rec();
                glPopMatrix();*/

                glTranslatef(0.0f, 0.0f, 12.8f);
                glColor3f(1,1,1);
                glPushMatrix();
                    glRotatef(90, 0, -1, 0);
                    Init_Light();
                    Rec();
                glPopMatrix();

                /*glPushMatrix();
                    glRotatef(theta, 0, 0, 1);
                    glTranslatef(0.0f, -5.0f, 2.5f);
                    Init_Light();
                    glColor3f(1,1,1);
                    Rec();
                glPopMatrix();*/

                //glRotatef(theta, 1, 0, 0);
            glPopMatrix();


            Init_Material();

            draw_chess(24);

            glPushMatrix();

            glTranslatef(0,0,height2);



            glPushMatrix();
            for (float i = 0; i < count; i++) {
                glPushMatrix();
                glRotatef(i * 360.0 / count, 0.0f, 0.0f, 1.0f);
                glTranslatef(5, -0.0f, -0.0f);
                    glPushMatrix();
                        glRotatef(180,1,0,0);
                        glTranslatef(0,0,-height);
                        draw_squares(rad, midRad, sides, height, 1.0 - (1.0 / count * i));
                    glPopMatrix();
                    glPushMatrix();
                        draw_squares(rad, midRad, sides, height, 1.0 - (1.0 / count * i));
                    glPopMatrix();

                    glPushMatrix();
                        glTranslatef(0, 0, height);
                        draw_triangles(rad, sides, 1.0 - (1.0 / count * i));
                    glPopMatrix();
                    draw_triangles(rad, sides, 1.0 - (1.0 / count * i));

                glPopMatrix();
            }
            glPopMatrix();

            glPopMatrix();

            glPopMatrix();

            SwapBuffers(hDC);

            theta += 1.0f;
            Sleep (1);
        }
    }

    /* shutdown OpenGL */
    DisableOpenGL(hwnd, hDC, hRC);

    /* destroy the window explicitly */
    DestroyWindow(hwnd);

    return msg.wParam;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_CLOSE:
            PostQuitMessage(0);
        break;

        case WM_DESTROY:
            return 0;

        case WM_KEYDOWN:
        {
            switch (wParam)
            {
                case VK_ESCAPE:
                    PostQuitMessage(0);
                break;
            }
        }
        break;

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }

    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC)
{
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;

    /* get the device context (DC) */
    *hDC = GetDC(hwnd);

    /* set the pixel format for the DC */
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);

    /* create and enable the render context (RC) */
    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC)
{
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}

