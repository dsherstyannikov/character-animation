#include "egg.h"
#include <time.h>
#include <stdlib.h>
#include "map.h"

void respawnEgg(int x) {
    srand(time(NULL));
    egg.timesTaken++;
    int num = 1 + rand() % (19 - 1 + 1);
    while(num == x){
        num = 1 + rand() % (19 - 1 + 1);
    }
    int i = 13;

    if (egg.timesTaken == 10) {
        egg.timesTaken = 1;
    }

    while (collisionMap[i][num] == 1){
        i--;
    }
    collisionMap[i][num] = 2;
    egg.x = (num-1)*50;
    egg.y = (i-0)*50;
}
