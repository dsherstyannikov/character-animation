#ifndef TEXTUR_H_INCLUDED
#define TEXTUR_H_INCLUDED

void draw_Animation(GLuint texture, int n, int frameLine, float posX, float posY, bool lookRight);
void Load_Texture( char *filename, GLuint *textureID, int swarp, int twarp, int filter);
void draw_Static(GLuint texture, float posX, float posY);
void Show_Background(GLuint texture);

#endif // TEXTUR_H_INCLUDED
