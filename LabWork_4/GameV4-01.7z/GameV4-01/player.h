#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED

#define WALK 0
#define STAY 1
#define JUMP 2

struct Player
{
    int velocity = 3;
    int jumpHeight=-1.0;
    int gravity=20.0;
    float posX=512.0;
    float posY=100.0;
    bool isOnFloor = true;
    bool lookRight = true;
    int frameLine = 1;
};
extern Player player;

void Player_Move();

int checkCollisionHorizontal(int deltaX, int deltaY);
int checkCollisionVertical(int deltaX, int deltaY);

#endif // PLAYER_H_INCLUDED
