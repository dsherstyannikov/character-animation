#ifndef EGG_H_INCLUDED
#define EGG_H_INCLUDED

struct Egg
{
    float x = 150;
    float y = 200;
    int timesTaken = 0;
};
extern Egg egg;

void respawnEgg(int);

#endif // EGG_H_INCLUDED
