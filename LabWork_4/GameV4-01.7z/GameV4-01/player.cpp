#include <gl/gl.h>
#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <malloc.h>
#include "player.h"
#include "map.h"
#include "egg.h"

void Player_Move(){
    const int JUMP_HEIGHT = 50;

    int collisionResult = checkCollisionVertical(75, 150);

    if(collisionResult != 1 && collisionResult != 2){
        player.posY += player.gravity / 2;
    } else {
        player.isOnFloor = true;
    }

    if (GetKeyState(VK_SPACE) < 0 && player.isOnFloor && collisionResult == 1){
        player.jumpHeight = JUMP_HEIGHT;
        player.isOnFloor = false;
        player.frameLine = JUMP;
    }

    if (GetKeyState('D') < 0 ){
        player.lookRight = true;
        player.posX += checkCollisionHorizontal(100, 110);
        if(player.isOnFloor){
            player.frameLine = WALK;
        }
    } else if (GetKeyState('A') < 0) {
        player.lookRight = false;
        player.posX -= checkCollisionHorizontal(0, 110);

        if(player.isOnFloor){
            player.frameLine = WALK;
        }
    } else if (player.isOnFloor){
        player.frameLine = STAY;
    }

    if(player.jumpHeight == -1){
        player.isOnFloor = true;
    } else if(!player.isOnFloor){
        player.posY -= player.jumpHeight - player.gravity;
        player.jumpHeight -= 1;
    }
}

int checkCollisionHorizontal(int deltaX, int deltaY){
    int x = floor((player.posX + deltaX)/50);
    int y = floor((player.posY + 0 + deltaY)/50);
    int current = collisionMap[y][x];
    int next = collisionMap[y][x+1];
    if(current == 2){
        collisionMap[y][x] = 0;
        respawnEgg(x);
    }
    if(next == 0 || next == 2){
        return player.velocity;
    } else {
        return 0;
    }
}

int checkCollisionVertical(int deltaX, int deltaY){
    int x = floor((player.posX + deltaX)/50);
    int y = floor((player.posY + deltaY)/50);
    int current = collisionMap[y][x];
    for(int i = 1; i <= 1; i++){
        if(current == 1 || collisionMap[y][x+1] == 1 ){
            return 1;
        } else if(current == 0 || current == 2){
            return 0;
        } else {
            return -1;
        }
    }
}


