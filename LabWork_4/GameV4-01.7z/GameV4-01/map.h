#ifndef MAP_H_INCLUDED
#define MAP_H_INCLUDED

extern int collisionMap[15][21];

#endif // MAP_H_INCLUDED
