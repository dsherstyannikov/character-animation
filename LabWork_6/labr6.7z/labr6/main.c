#include <windows.h>
#include <gl/gl.h>

#include "camera/camera.h"

LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM);
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);
void DisableOpenGL(HWND, HDC, HGLRC);

float vertex[] = {-0.2,-0.2,0,  0.2,-0.2,0,  0.2,0.2,0,  -0.2,0.2,0};

void WndResize(int x, int y){
    glViewport(0,0,x,y);
    float k = x / (float)y;
    float sz = 0.1;
    glLoadIdentity();
    glFrustum(-k*sz, k*sz, -sz, sz, sz*2, 100);//persp. proectia
}

void Camera_Move(){
    Camera_MoveDirectional(GetKeyState('W')< 0 ? 1 : GetKeyState('S')< 0 ? -1 : 0,GetKeyState('D')< 0 ? 1 : GetKeyState('A')< 0 ? -1 : 0,0.3);
    Camera_AutoMoveByMouse(400,400,0.2);
}

void Rec(){
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0 ,vertex);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    glDisableClientState(GL_VERTEX_ARRAY);
}

void draw_chess(int size)
{

    float normal_vert[]={0,0,1, 0,0,1, 0,0,1, 0,0,1};
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT,0,&normal_vert);


    float color = 0.0;
    int start = floor(size / 2);
    for(float i = 0; i < size; i++){
        color =  fmod((color + 1.0), 2.0);
        for(float j = 0; j < size; j++){
            color =  fmod((color + 1.0), 2.0);
            glBegin(GL_QUADS);
            glColor3f(color,color,color);

            //glNormal3f(0.0f+i-start, 0.0f+j-start, 0.0f);
            glVertex3f(0.0f+i-start, 0.0f+j-start, 0.0f);

            //glNormal3f(0.0f+i-start, 1.0f+j-start, 0.0f);
            glVertex3f(0.0f+i-start, 1.0f+j-start, 0.0f);

            //glNormal3f(1.0f+i-start, 1.0f+j-start, 0.0f);
            glVertex3f(1.0f+i-start, 1.0f+j-start, 0.0f);

            //glNormal3f(1.0f+i-start, 0.0f+j-start, 0.0f);
            glVertex3f(1.0f+i-start, 0.0f+j-start, 0.0f);


            glEnd();
        }
    }
    glDisable(GL_NORMAL_ARRAY);
}

void Draw_Cube(float r,float g,float b){
GLfloat vertices[] = {
     -0.5f, -0.5f, -0.5f,
     0.5f, -0.5f, -0.5f,
     0.5f, 0.5f, -0.5f,
     -0.5f, 0.5f, -0.5f,
     -0.5f, -0.5f, 0.5f,
     0.5f, -0.5f, 0.5f,
     0.5f, 0.5f, 0.5f,
     -0.5f, 0.5f, 0.5f
    };
    GLuint indices[] = {
     0, 1, 2,
     2, 3, 0,
     1, 5, 6,
     6, 2, 1,
     7, 6, 5,
     5, 4, 7,
     4, 0, 3,
     3, 7, 4,
     4, 5, 1,
     1, 0, 4,
     3, 2, 6,
     6, 7, 3
    };
    GLfloat normals[] = {
     0.0f, 0.0f, -1.0f,
     0.0f, 0.0f, -1.0f,
     0.0f, 0.0f, -1.0f,
     0.0f, 0.0f, -1.0f,
     0.0f, 0.0f, 1.0f,
     0.0f, 0.0f, 1.0f,
     0.0f, 0.0f, 1.0f,
     0.0f, 0.0f, 1.0f,
     -1.0f, 0.0f, 0.0f,
     -1.0f, 0.0f, 0.0f,
     -1.0f, 0.0f, 0.0f,
     -1.0f, 0.0f, 0.0f,
     1.0f, 0.0f, 0.0f,
     1.0f, 0.0f, 0.0f,
     1.0f, 0.0f, 0.0f,
     1.0f, 0.0f, 0.0f,
     0.0f, -1.0f, 0.0f,
     0.0f, -1.0f, 0.0f,
     0.0f, -1.0f, 0.0f,
     0.0f, -1.0f, 0.0f,
     0.0f, 1.0f, 0.0f,
     0.0f, 1.0f, 0.0f,
     0.0f, 1.0f, 0.0f,
     0.0f, 1.0f, 0.0f
    };
    glColor3f(r,g,b);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, vertices);
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT, 0, normals);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, indices);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
}


/*            ��������, ���������                 */
void Init_Light()
{
    glEnable(GL_LIGHTING); //����� ��������� ��� ����� ������������
    glShadeModel(GL_SMOOTH);
    GLfloat light_position[] = { 0, 0, 1.0, 1.0f }; //������� ���������
    GLfloat light_spot_direction[] = {0.0, 1.0, -1.0, 1.0}; // ������� ����
    GLfloat light_ambient[] = { 0.2f, 0.2f, 0.2f, 0.5f }; //���������
    GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 0.5f }; //���������
    GLfloat light_specular[] = { 0.2f, 0.2f, 0.2f, 32.0f }; //���������
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 90); // ����� ��� ������������� ���������
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light_spot_direction);
    glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 8.0); // ���������� �������� ������������� �������������� �������� ��� ��������� LIGHT0
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glEnable(GL_LIGHT0); // �������� ����� LIGHT0


}

void Init_Material()
{
    glEnable(GL_COLOR_MATERIAL); //���������� ������������� ���������
    glShadeModel(GL_SMOOTH); // ���������� �������



    GLfloat material_ambient[] = {1.0, 1.0, 1.0, 0.5};

    GLfloat material_diffuse[] = { 1.0f, 1.0f, 1.0f, 0.5f };

    GLfloat material_specular[] = { 1.0f, 1.0f, 1.0f, 32.0f };
    GLfloat material_shininess[] = { 50.0f }; //����� ���������
    glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess);


    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}







int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{
    WNDCLASSEX wcex;
    HWND hwnd;
    HDC hDC;
    HGLRC hRC;
    MSG msg;
    BOOL bQuit = FALSE;
    float theta = 0.0f;

    /* register window class */
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC;
    wcex.lpfnWndProc = WindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = "GLSample";
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);;


    if (!RegisterClassEx(&wcex))
        return 0;

    /* create main window */
    hwnd = CreateWindowEx(0,
                          "GLSample",
                          "OpenGL Sample",
                          WS_OVERLAPPEDWINDOW,
                          CW_USEDEFAULT,
                          CW_USEDEFAULT,
                          800,
                          800,
                          NULL,
                          NULL,
                          hInstance,
                          NULL);

    ShowWindow(hwnd, nCmdShow);

    /* enable OpenGL for the window */
    EnableOpenGL(hwnd, &hDC, &hRC);

    RECT rct;
    GetClientRect(hwnd, &rct);
    WndResize(rct.right, rct.bottom);
    glEnable(GL_DEPTH_TEST);

    /*  09  */
    /*glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-0.1, 0.1, -0.1, 0.1, 0.2, 1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();*/



    /*Init_Light();
    Init_Material();
*/
    /* program main loop */
    while (!bQuit)
    {
        /* check for messages */
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            /* handle or dispatch messages */
            if (msg.message == WM_QUIT)
            {
                bQuit = TRUE;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        else
        {
            /* OpenGL animation code goes here */

            glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //������� ������ �������




            glPushMatrix();
            if(GetForegroundWindow() == hwnd){
                Camera_Move();
            }
            Camera_Apply();



            glPushMatrix();
                glPushMatrix();

                    glRotatef(theta, 0, 0, 1);
                    glTranslatef(0.0f, -3.0f, 2.5f);
                    Init_Light();
                    glColor3f(1,1,1);

                    Rec();
                glPopMatrix();

                glRotatef(theta, 1, 0, 0);

            glPopMatrix();


            Init_Material();


            glBegin(GL_TRIANGLES);

                glColor3f(1.0f, 0.0f, 0.0f);   glVertex2f(0.0f,   1.0f);
                glColor3f(0.0f, 1.0f, 0.0f);   glVertex2f(0.87f,  -0.5f);
                glColor3f(0.0f, 0.0f, 1.0f);   glVertex2f(-0.87f, -0.5f);

            glEnd();

            //glRotatef(theta, 0.0f, 0.0f, 1.0f);

            glBegin(GL_LINES);

                glColor3f(1.0f, 1.0f, 1.0f);   glVertex3f(-100.0f,   0.0f, 0.0f);//white x
                glColor3f(1.0f, 1.0f, 1.0f);   glVertex3f(100.0f,  0.0f, 0.0f);

                glColor3f(0.0f, 1.0f, 0.0f);   glVertex3f(0.0f,   100.0f, 0.0f);//green y
                glColor3f(0.0f, 1.0f, 0.0f);   glVertex3f(0.0f,  -100.0f, 0.0f);

                glColor3f(1.0f, 0.0f, 0.0f);   glVertex3f(0.0f,   0.0f, -100.0f);//red z
                glColor3f(1.0f, 0.0f, 0.0f);   glVertex3f(0.0f,   0.0f, 100.0f);

            glEnd();

            glPushMatrix();
                glTranslatef(3.0f, 0.0f, 1.0f);
                Draw_Cube(1,0,0);
            glPopMatrix();

            glPushMatrix();
                glTranslatef(-3.0f, 0.0f, 1.0f);
                Draw_Cube(0,1,0);
            glPopMatrix();

            glPushMatrix();
                glTranslatef(0.0f, 3.0f, 1.0f);
                Draw_Cube(0,0,1);
            glPopMatrix();

            glPushMatrix();
                glTranslatef(0.0f, -3.0f, 1.0f);
                Draw_Cube(1,1,1);
            glPopMatrix();

            glPushMatrix();
                glTranslatef(0.0f, 0.0f, 1.0f);
                Draw_Cube(1,1,0);
            glPopMatrix();

            draw_chess(20);


            glPopMatrix();





            SwapBuffers(hDC);

            theta += 1.0f;
            Sleep (1);
        }
    }

    /* shutdown OpenGL */
    DisableOpenGL(hwnd, hDC, hRC);

    /* destroy the window explicitly */
    DestroyWindow(hwnd);

    return msg.wParam;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_CLOSE:
            PostQuitMessage(0);
        break;

        case WM_DESTROY:
            return 0;

        case WM_KEYDOWN:
        {
            switch (wParam)
            {
                case VK_ESCAPE:
                    PostQuitMessage(0);
                break;
            }
        }
        break;

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }

    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC)
{
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;

    /* get the device context (DC) */
    *hDC = GetDC(hwnd);

    /* set the pixel format for the DC */
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);

    /* create and enable the render context (RC) */
    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC)
{
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}

